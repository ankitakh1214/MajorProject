import { render } from '@testing-library/react';
import React from 'react';
import '../../App.css';

export default function AboutUs() {
  return <h1 className='about-us'>Hiii</h1>;
}
